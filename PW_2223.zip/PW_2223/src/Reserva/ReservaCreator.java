package Reserva;

import Usuario.Usuario;

public abstract class ReservaCreator {
	
	public abstract boolean reservaInfantil(Usuario usuario, int duracion);
	
	public abstract boolean reservaAdulto(Usuario usuario, int duracion);
	
	public abstract boolean reservaFamiliar(Usuario usuario, int duracion);

}

package Reserva;

import java.util.Date;

import Usuario.Usuario;

enum TipoReserva
{
	ADULTO,
	INFANTIL,
	FAMILIAR;
}

public class ReservaIndividual extends ReservaCreator {
	
	protected int id_usuario_reserva; 
	private Date fecha_reserva;
	private TipoReserva tipo_reserva;
	private int duracion;
	private double precio;
	private double descuento;
	
	public ReservaIndividual(Usuario usuario, TipoReserva tipo_reserva,Date reserva) {
		
		
		
	}

	public int getId_usuario_reserva() {
		return id_usuario_reserva;
	}

	public void setId_usuario_reserva(int id_usuario_reserva) {
		this.id_usuario_reserva = id_usuario_reserva;
	}

	public Date getFecha_reserva() {
		return fecha_reserva;
	}

	public void setFecha_reserva(Date fecha_reserva) {
		this.fecha_reserva = fecha_reserva;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public double getDescuento() {
		return descuento;
	}

	public void setDescuento(float descuento) {
		this.descuento = descuento;
	}	
	
	@Override
	public String toString() {
		return "ReservaIndividual [id_usuario_reserva=" + id_usuario_reserva + ", fecha_reserva=" + fecha_reserva
				+ ", tipo_reserva=" + tipo_reserva + ", duracion=" + duracion + ", precio=" + precio + ", descuento="
				+ descuento + "]";
	}
	
	@Override
	public boolean reservaInfantil(Usuario usuario, int duracion)
	{
		
	}

	
	public boolean reservaAdulto(Usuario usuario, int duracion)
	{
		
	}
	
	@Override
	public boolean reservaFamiliar(Usuario usuario, int duracion)
	{
		
	}
	
	
}

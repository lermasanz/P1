package Reserva;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import Usuario.Usuario;

enum TipoBono
{
	ADULTO,
	INFANTIL,
	FAMILIAR;
}

public class ReservaBono extends ReservaCreator{
	
	
	
		
	public int getId_usuario_uso_bono() {
		return id_usuario_uso_bono;
	}

	public void setId_usuario_uso_bono(int id_usuario_uso_bono) {
		this.id_usuario_uso_bono = id_usuario_uso_bono;
	}

	public Date getFecha_caducidad() {
		return fecha_caducidad;
	}

	public void setFecha_caducidad(Date fecha_caducidad) {
		this.fecha_caducidad = fecha_caducidad;
	}

	public Date getFecha_reserva() {
		return fecha_reserva;
	}

	public void setFecha_reserva(Date fecha_reserva) {
		this.fecha_reserva = fecha_reserva;
	}

	public int getId_usuario_propietario() {
		return id_usuario_propietario;
	}

	public void setId_usuario_propietario(int id_usuario_propietario) {
		this.id_usuario_propietario = id_usuario_propietario;
	}

	public TipoBono getTipo_bono() {
		return tipo_bono;
	}

	public void setTipo_bono(TipoBono tipo_bono) {
		this.tipo_bono = tipo_bono;
	}

	public int[] getDuracion_sesiones() {
		return duracion_sesiones;
	}

	public void setDuracion_sesiones(int[] duracion_sesiones) {
		this.duracion_sesiones = duracion_sesiones;
	}

	public int getSesiones_usadas() {
		return sesiones_usadas;
	}

	public void setSesiones_usadas(int sesiones_usadas) {
		this.sesiones_usadas = sesiones_usadas;
	}

	public double[] getPrecio_sesiones() {
		return precio_sesiones;
	}

	public void setPrecio_sesiones(double[] precio_sesiones) {
		this.precio_sesiones = precio_sesiones;
	}
	
	public ReservaBono(Usuario usuario, TipoBono tipoBono, Date fecha_reserva)
	{
		
	}
	
	
	
	@Override
	public boolean reservaInfantil(Usuario usuario, int duracion)
	{
		
	}
	
	@Override
	public boolean reservaAdulto(Usuario usuario, int duracion)
	{
		
	}
	
	@Override
	public boolean reservaFamiliar(Usuario usuario, int duracion)
	{
		
	}

}

package kart;

public enum Estado_Kart
{
	DISPONIBLE,
	MANTENIMIENTO,
	RESERVADO;
}

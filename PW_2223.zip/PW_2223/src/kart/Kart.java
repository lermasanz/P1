package kart;

public class Kart {
	
	private int id;   
	private boolean paraInfantil;  
	private Estado_Kart estado;
	
	public Kart() {
		this.id=-1;
		this.paraInfantil=false;
		this.estado=Estado_Kart.DISPONIBLE;
	}
	
	public Kart(int id, boolean paraInfantil, Estado_Kart estado,int idCircuit) {
		this.id = id;
		this.paraInfantil = paraInfantil;
		this.estado = estado;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public boolean paraInfantil() {
		return paraInfantil;
	}
		
	public void setParaInfantil(boolean paraInfantil) {
		this.paraInfantil = paraInfantil;
	}
	
	public Estado_Kart getEstado() {
		return estado;
	}
	
	public void setEstado(Estado_Kart estado) {
		this.estado = estado;
	}
	
	public String toString() {
		return "Kart [id=" + id + ", paraInfantil=" + paraInfantil + ", estado=" + estado + "]";
	}

	
}

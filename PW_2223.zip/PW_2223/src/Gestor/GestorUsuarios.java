package Gestor;

import java.util.ArrayList;
import Usuario.*;

public class GestorUsuarios {

	ArrayList<Usuario> usuarios;
	
	public void alta_usuario(Usuario u)
	{
		
	}
	
	public void modificar_usuario(Usuario u)
	{
		
	}
	
	public void listar_usuarios()
	{
		
	}
	
}

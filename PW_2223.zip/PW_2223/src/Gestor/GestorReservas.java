package Gestor;

import java.util.ArrayList;
import java.util.Date;

import Reserva.*;
import Pista.*;


public class GestorReservas {
	
	private ArrayList<ReservaIndividual> reservas_individuales;
	private ArrayList<ReservaBono> reservas_bono;
	
	public GestorReservas()
	{
		
	}
	
	public void realizar_reserva()
	{
		
	}
	
	public void modificar_reserva(int id_reserva)
	{
		
	}
	
	public void anular_reserva(int id_reserva) 
	{
		
	}
	
	public void consultar_reservas_futuras(Date fecha) //posteriores a una fecha o a la actual
	{
		
	}
	
	public void consultar_reserva(Date fecha, Pista p) //para un dia y pista
	{
		
	}

}

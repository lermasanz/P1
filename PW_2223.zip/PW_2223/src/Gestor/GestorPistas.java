package Gestor;

import java.util.ArrayList;
import Pista.*;
import Usuario.*;

public class GestorPistas {
	
	private ArrayList<Pista> pistas;
	private ArrayList<Usuario> usuarios;
	
	public void asociar_kart_a_pista()
	{
		
	}
	
	public void listar_pistas_mantenimiento()
	{
		
	}
	
	public void pistas_libres(int numero_karts, Estado_Pista tipo_pista)
	{
		
	}

}

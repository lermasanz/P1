package Usuario;

import java.util.Date;
import java.text.SimpleDateFormat; 
import java.util.GregorianCalendar;
import java.util.Calendar;


public class Usuario {
	
	
    private int id;
    private String nombre;
    private String apellidos;
    private Date fechaNacimiento;
    private Date fechaInscripcion;
    private String email;

   
    public Usuario() {
        setId(0);
        setNombre("");
        setApellidos("");
        setFechaNacimiento(new Date());
        setFechaInscripcion(new Date());
        setEmail("");
    }
    
    public Usuario(int id, String nombre, String apellidos, Date fechaNacimiento, Date fechaInscripcion, String email) {
        setId(id);
        setNombre(nombre);
        setApellidos(apellidos);
        setFechaNacimiento(fechaNacimiento);
        setFechaInscripcion(fechaInscripcion);
        setEmail(email);
    }

    public int getId() {
        return this.id;
    }
    
    public String getNombre() {
        return this.nombre;
    }

    public String getApellidos() {
        return this.apellidos;
    }

    public Date getFechaNacimiento() {
        return this.fechaNacimiento;
    }

    public Date getFechaInscripcion() {
        return this.fechaInscripcion;
    }

    public String getEmail() {
        return this.email;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setFechaInscripcion(Date fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int calcularEdad() {
        Calendar fechaNacimiento = new GregorianCalendar();
        Calendar hoy = new GregorianCalendar();

        fechaNacimiento.setTime(getFechaNacimiento());
        hoy.setTime(new Date());

        int edad = hoy.get(Calendar.YEAR) - fechaNacimiento.get(Calendar.YEAR);
        return edad;
    }

    public int calcularAntiguedad() {
        Calendar fechaInscripcion = new GregorianCalendar();
        Calendar hoy = new GregorianCalendar();

        fechaInscripcion.setTime(getFechaInscripcion());
        hoy.setTime(new Date());

        int antiguedad = hoy.get(Calendar.MONTH) - fechaInscripcion.get(Calendar.MONTH);
        return antiguedad;
    }
    
    @Override
    public String toString() {
        String str = "";
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        str += "\tNombre: " + getNombre() + System.lineSeparator();
        str += "\tApellidos: " + getApellidos() + System.lineSeparator();
        str += "\tFecha de nacimiento: " + df.format(getFechaNacimiento()) + System.lineSeparator();
        str += "\tEdad: " + calcularEdad() + System.lineSeparator();
        str += "\tFecha de inscripcion: " + df.format(getFechaInscripcion()) + System.lineSeparator();
        str += "\tAntigüedad: " + calcularAntiguedad() + " meses" + System.lineSeparator();
        str += "\tEmail: " + getEmail() + System.lineSeparator();
        return str;
    }
}

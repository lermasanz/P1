package Pista;

public enum Estado_Pista
{
	INFANTIL,
	ADULTOS,
	FAMILIAR;
}
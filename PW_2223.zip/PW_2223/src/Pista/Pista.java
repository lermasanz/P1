package Pista;

import java.util.ArrayList;
import kart.*;

public class Pista {

	private int id;
	private String nombre;
	private boolean estado;//false NO DISPONIBLE RESERVAS, false SI DISPONIBLE RESERVAS
	private Estado_Pista dificultad;
	private int max_karts;
	private ArrayList<Kart> lista_karts;
	
	public Pista()
	{
		this.id = 0;
		this.nombre = "";
		this.estado = false;
		this.dificultad  = Estado_Pista.INFANTIL;
		this.max_karts = 0;
		this.lista_karts = new ArrayList<Kart>();
	}
	
	public Pista(int id, String nombre, boolean estado, Estado_Pista dificultad, int max_karts)
	{
		this.id = id;
		this.nombre = nombre;
		this.estado = estado;
		this.dificultad  = dificultad;
		this.max_karts = max_karts;
		this.lista_karts = new ArrayList<Kart>();
	}
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getnombre() {
		return nombre;
	}
	
	public void setnombre(String nombre) {
		this.nombre = nombre;
	}
	
	public boolean isestado() {
		return estado;
	}
	
	public void setestado(boolean estado) {
		this.estado = estado;
	}
	public Estado_Pista geEstado_Pista() {
		return dificultad;
	}
	
	public void seEstado_Pista(Estado_Pista dificultad) {
		this.dificultad = dificultad;
	}
	
	public int getmax_karts() {
		return max_karts;
	}
	
	public void setmax_karts(int max_karts) {
		this.max_karts = max_karts;
	}
	
	public ArrayList<Kart> getlista_karts() {
		return lista_karts;
	}
	
	public void setlista_karts(ArrayList<Kart> lista_karts) {
		this.lista_karts = lista_karts;
	}
	
	public Estado_Pista getDificultad() {
		return dificultad;
	}

	public void setDificultad(Estado_Pista dificultad) {
		this.dificultad = dificultad;
	}

	@Override
	public String toString() {
		return "Pista [nombre=" + nombre + ", estado=" + estado + ", dificultad=" + dificultad + ", max_karts="
				+ max_karts + ", lista_karts=" + lista_karts + "]";
	}
	
	public int consultarKartsDisponibles()
	{
		int cont = 0;
		for(int i=0;i<this.lista_karts.size(); i++)
		{
			if(this.lista_karts.get(i).getEstado() == Estado_Kart.DISPONIBLE)
			{
				cont++;
			}
		}
		return cont;
	}
	
	public void asociarKartAPista(Kart k)
	{
		if(this.dificultad == Estado_Pista.INFANTIL && k.paraInfantil()==false)
		{
			this.lista_karts.add(k);
		}
		else if(this.dificultad == Estado_Pista.ADULTOS && k.paraInfantil() == true)
		{
			this.lista_karts.add(k);
		}
		else if(this.dificultad == Estado_Pista.FAMILIAR)
		{
			this.lista_karts.add(k);
		}
	}
	
}

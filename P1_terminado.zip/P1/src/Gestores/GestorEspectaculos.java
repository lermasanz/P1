package Gestores;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import Espectaculos.Espectaculo;
import Espectaculos.Sesion;

import java.time.format.DateTimeFormatter;

public class GestorEspectaculos {
	
	
	
	private static GestorEspectaculos instance= null;
	
	static ArrayList<Espectaculo> Espectaculos = new ArrayList();
	
	private ArrayList<Sesion> sesiones = new ArrayList<Sesion>();
	
	private GestorEspectaculos()
	{
		
	}
	
	public static GestorEspectaculos getInstance()
	{
		if(instance==null)
		{
			instance= new GestorEspectaculos();
		}
		
		return instance;
	}
	
	
	
	
	public ArrayList<Espectaculo> getEspectaculo()
	{
		return Espectaculos;
	}
	
	
	public void setEspectaculo(ArrayList<Espectaculo> Espectaculos)
	{
		this.Espectaculos=Espectaculos;
	}
	
	
		public String imprimir_sesiones(int id_espectaculo) {
			
			String resultado = "";
			
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if(Espectaculos.get(i).getId_espectaculo() == id_espectaculo) {
					
					resultado = Espectaculos.get(i).getTitulo() + "Sesiones:" + Espectaculos.get(i).todas_sesiones();
				}
			}
			
			return resultado;
		}
		
		
		
		
		
		public void borrar_sesiones(int id_espectaculo, String[] Sesion_array) {
			
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if(Espectaculos.get(i).getId_espectaculo() == id_espectaculo) {
					
					Espectaculos.get(i).BorrarSesiones(Sesion_array);
				}
			}
		}
		
		public void borrar_todo(int borrar) {
			
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if(Espectaculos.get(i).getId_espectaculo() == borrar) {
					
					Espectaculos.remove(i);
				}
			}
		}
		
		
		
		
		
		public String buscar(String buscado) {
			
			String resultado = "";
			
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if( (Espectaculos.get(i).getTitulo()==buscado) || (Espectaculos.get(i).getCategoria()==buscado) ) {
					
					resultado = Espectaculos.get(i).getId_espectaculo() + "-" + Espectaculos.get(i).getTitulo();
				}
			}
			
			return resultado;
			
		}
		
		
		
		
		
		public int Entradas_disponibles(int id_espectaculo, LocalDate fecha) {
			
			int entradas_disponibles;
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if(Espectaculos.get(i).getId_espectaculo() == id_espectaculo) {
					
					entradas_disponibles=(Espectaculos.get(i).getAforo() - Espectaculos.get(i).Vender_entradas(fecha));
					
					
					return entradas_disponibles;
					
				}
			}
			
			return 0;
		}
		
		public String Sesiones_disponibles() {
			
			String resultado = "";
			
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if(Espectaculos.get(i).getSesiones_disponibles() != "") {
					
					resultado = Espectaculos.get(i).getTitulo() + Espectaculos.get(i).getSesiones_disponibles();
					
				}
			}
			
			return resultado;
		}
		
		
		public int Entradas_vendidas(int id_espectaculo, LocalDate fecha) {
		
			for(int i=0; i<Espectaculos.size(); i++) {
				
				if(Espectaculos.get(i).getId_espectaculo() == id_espectaculo) {
					
					return Espectaculos.get(i).Vender_entradas(fecha);
				}
			}
			
			return 0;
		}
	
	
	public static void AltaEspectaculo() throws IOException
	{
		Scanner teclado = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Espectaculo e=new Espectaculo();
		
		Sesion s= new Sesion();
		
		int id_espectaculo;
		String titulo;
		String descripcion;
		String categoria;
		int aforo_maximo;
		int numero_entradas;
		
		
		System.out.println("Introduce el ID del espectaculo: ");
		id_espectaculo=teclado.nextInt();
		
		System.out.println("Introduce el titulo del espectaculo: ");
		titulo=reader.readLine();
		
		System.out.println("Introduce la descripci�n del espectaculo: ");
		descripcion=reader.readLine();
		
		System.out.println("Introduce la categor�a del espectaculo: ");
		categoria=reader.readLine();
		
		System.out.println("Introduce el aforo m�ximo del espectaculo: ");
		aforo_maximo=teclado.nextInt();
		
		System.out.println("Introduce el numero de entradas del espectaculo");
		numero_entradas=teclado.nextInt();
		
		
		System.out.println("Seleccione el tipo de espectaculo:");
		System.out.println("1.Puntual\n2.Multiple\n3.Temporada");
		
		e.setId_espectaculo(id_espectaculo);
		e.setTitulo(titulo);
		e.setDescripcion(descripcion);
		e.setCategoria(categoria);
		e.setAforo(aforo_maximo);
		
		int tipo;
		
		
		
		
			tipo=teclado.nextInt();
			
			if(tipo==1)
			{
				System.out.print("Introduzca la fecha del espectaculo");
				e.setFecha(Functions.leerFecha("Fecha(YYYY/MM/DD): "));
				s.setEntradas(numero_entradas);
				
				
				
			}
			
			else if(tipo==2)
			{
				System.out.print("Introduzca el numero de sesiones a a�adir:");
				
				int sesiones=teclado.nextInt();
				
				for(int i=0;i<sesiones;i++)
				{
					System.out.println("Introduzca la fecha de la sesion que desea a�adir");
					e.setFecha(Functions.leerFecha("Fecha(YYYY/MM/DD): "));
				}
				
				
			}
			
			else if(tipo==3)
			{
				System.out.print("Introduzca la fecha de inicio:");
				e.setFecha(Functions.leerFecha("Fecha(YYYY/MM/DD): "));
				
				System.out.print("Introduzca la fecha de fin:");
				e.setFecha(Functions.leerFecha("Fecha(YYYY/MM/DD): "));
				
				
			}
			else
			{
				System.out.print("Error al introducir el tipo");
			}
			
			Espectaculos.add(e);
		
	}
	
	public static void mostrarEspectaculo()
	{
		for(int i=0;i<Espectaculos.size();i++)
		{
			System.out.println(Espectaculos.get(i));
		}
	}
	
	
	
	
	public static void CancelarEspectaculo()
	{
		Scanner entrada= new Scanner(System.in);
		GestorEspectaculos Gestor_espectaculo= GestorEspectaculos.getInstance();
		System.out.println("Introduzca el id del espectaculo que desea cancelar:");
		int borrar_id = entrada.nextInt();
		
		
		
		Gestor_espectaculo.imprimir_sesiones(borrar_id);
		
		System.out.println("1. Cancelar todas las sesiones.");
		System.out.println("2. Cancelar las sesiones seleccionadas.");
		int opcion = entrada.nextInt();
		
		if(opcion == 1) {
		
			Gestor_espectaculo.borrar_todo(borrar_id);
		}
		else if(opcion == 2) {
			
			System.out.println("Introduzca las sesiones que desea cancelar");
			String sesiones = entrada.nextLine();
			String[] sesion_array = sesiones.split(" ");
			
			Gestor_espectaculo.borrar_sesiones(borrar_id, sesion_array);
		}
		else {
			
			System.out.println("Error al introducir la opcion");
		}
	}
	
	
	
	public static void ActualizarEspectaculo()
	{
		
		
		Scanner entrada = new Scanner(System.in);
		 int posicion;
		 int id_espectaculo;
		 String titulo;
		 String descripcion;
		 String categoria;
		 int aforo_maximo;
		 for(int i=0;i<Espectaculos.size();i++){	        	
	        	System.out.println(Espectaculos.get(i));
	    
	        }
		 	System.out.print("\nIntroduzca la posici�n del objeto que quieres modificar comenzando desde la posicion 0: ");
	        posicion=entrada.nextInt();
		 	System.out.print("\nIntroduzca el ID del espectaculo por el que desea modificarlo: ");
	        id_espectaculo=entrada.nextInt();
	        Espectaculos.get(posicion).setId_espectaculo(id_espectaculo);
	        System.out.print("\nIntroduzca el titulo del espectaculo por el que desea modificarlo: ");
	        titulo=entrada.next();
	        Espectaculos.get(posicion).setTitulo(titulo);
	        System.out.print("\nIntroduzca la descripcion por el que desea modificarlo: ");
	        descripcion=entrada.next();
	        Espectaculos.get(posicion).setDescripcion(descripcion);
	        System.out.print("\nIntroduzca la categoria por el que desea modificarlo: ");
	        categoria=entrada.next();
	        Espectaculos.get(posicion).setCategoria(categoria);
	        System.out.print("\nIntroduzca el aforo maximo del espectaculo por el que desea modificarlo: ");
	        aforo_maximo=entrada.nextInt();
	        Espectaculos.get(posicion).setId_espectaculo(id_espectaculo);
	        Espectaculos.get(posicion).setTitulo(titulo);
	        Espectaculos.get(posicion).setDescripcion(descripcion);
	        Espectaculos.get(posicion).setCategoria(categoria);
	        Espectaculos.get(posicion).setAforo(aforo_maximo);
		
		
		
	}
	
	
	public static void BuscarEspectaculo()
	{
		Scanner entrada= new Scanner(System.in);
		GestorEspectaculos Gestor_espectaculo= GestorEspectaculos.getInstance();
		System.out.println("Introduzca el titulo o categoria:");
		String buscar = entrada.nextLine();
		
		String resultado = Gestor_espectaculo.buscar(buscar);
		
		if(resultado == "") {
			
			System.out.println("No se ha encontrado ningun espectaculo que coincida.");
		}
		else {
			System.out.println(resultado);
		}
		
		
		
	}
	
	
	public static void EntradasVendidas()
	{
		Espectaculo e=new Espectaculo();
		Scanner entrada=new Scanner(System.in);
		GestorEspectaculos Gestor_espectaculo= GestorEspectaculos.getInstance();
		System.out.println("Introduzca el id del espectaculo:");
		int id_espectaculo = entrada.nextInt();
		
		for(int i=0;i<Espectaculos.size();i++){	        	
        	System.out.println(Espectaculos.get(i));
        	
		}
		
		System.out.println(Gestor_espectaculo.imprimir_sesiones(id_espectaculo));

		System.out.println("Introduzca la fecha: ");
		
		e.setFecha(Functions.leerFecha("Fecha(YYYY/MM/DD): "));
		
		
		System.out.println(Gestor_espectaculo.Entradas_vendidas(id_espectaculo, e.getFecha()));
		
		
		
		
	}
	
	public static void EntradasDisponibles()
	{
		Scanner entrada=new Scanner(System.in);
		GestorEspectaculos Gestor_espectaculo= GestorEspectaculos.getInstance();
		
		LocalDate fecha;
		Espectaculo e=new Espectaculo();
		System.out.println("Introduzca el id del espectaculo:");
		int id_espectaculo = entrada.nextInt();
		
		for(int i=0;i<Espectaculos.size();i++){	        	
        	System.out.println(Espectaculos.get(i));
        	
		}
		
		System.out.println(Gestor_espectaculo.imprimir_sesiones(id_espectaculo));
		
		System.out.println("Introduzca la fecha:");
		
	
		e.setFecha(Functions.leerFecha("Fecha(YYYY/MM/DD): "));
		
		System.out.println(Gestor_espectaculo.Entradas_disponibles(id_espectaculo,e.getFecha()));
	}
	
	public static void EspectaculosDisponibles()
	{
		GestorEspectaculos Gestor_espectaculo= GestorEspectaculos.getInstance();
		if(Gestor_espectaculo.Sesiones_disponibles() == "") {
			
			System.out.println("No hay espectaculos disponibles.");
		}
		else {
			
			System.out.println(Gestor_espectaculo.Sesiones_disponibles());
		}
	}
	
	
	
}
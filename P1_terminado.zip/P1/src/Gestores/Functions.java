package Gestores;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import Gestores.GestorEspectaculos;

public class Functions {
	
	public static LocalDate leerFecha(String Cadena) {
        // Lee una cadena mostrando una cadena que se pasa como parámetro

        //	Creamos el objeto de entrada de datos de tipo BufferedReader
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));

        String cadenaRetorno = "";

        boolean continuar = false;
        LocalDate fecha = null;
        do {
            System.out.print(Cadena);
            try {

                cadenaRetorno = entrada.readLine();

                DateTimeFormatter formatAmerican = DateTimeFormatter.ofPattern("yyyy/LL/dd");

                fecha = LocalDate.parse(cadenaRetorno, formatAmerican);
                continuar = false;
            } catch (IOException ex) {
                System.out.println("Se ha producido un error de entrada/salida genérico.");
                continuar = true;
               
            } catch (DateTimeParseException ex) {
                System.out.println("Se ha producido un error de formato en la fecha, el formato debe ser AAAA/MM/DD.");
                continuar = true;
               
            }
        } while (continuar);
        return fecha;
    }
	
	
	
	 
	 
	 public static LocalDate parseFecha(String fecha) {
	        DateTimeFormatter formatAmerican = DateTimeFormatter.ofPattern("yyyy/LL/dd");
	        LocalDate fechaDate = null;
	        try {
	            fechaDate = LocalDate.parse(fecha, formatAmerican);
	        } catch (DateTimeParseException ex) {
	            System.out.println(ex);
	        }
	        return fechaDate;
	    }
	

}
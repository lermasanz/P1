package Gestores;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

import Usuario.Espectador;
import Critica.Critica;

public class GestorUsuario {
	
	private static GestorUsuario instance = null;
	static ArrayList<Espectador> espectadores = new ArrayList();
	static ArrayList<Critica>criticas = new ArrayList();
	private GestorUsuario() {
		
	}
	
	public static GestorUsuario getInstance() {
		if(instance == null) {
			instance = new GestorUsuario();
		}
	
		return instance;
	
	}
	
	 public static void leerEspectador()
	    {
	  
	        
	        
	        Scanner teclado = new Scanner(System.in);
	        Espectador p;
	        p= new Espectador();

	 
	        String nombre1;
	        String Apellido;
	        String nick;
	        String correo;
	        String pass;
	        int ID;
	        System.out.print("Introduzca el ID:  ");
	        ID = teclado.nextInt();
	        p.setUserId(ID);
	        System.out.print("Introduzca el nombre:  ");
	        nombre1 = teclado.next();
	        p.setName(nombre1);
	        System.out.print("Introduzca el apellido: ");
	        Apellido = teclado.next();
	        p.setSurname(Apellido);
	        System.out.println("Introduzca el Nick:");
	        nick=teclado.next();
	        p.setNick(nick);
	        System.out.print("Introduzca email:");
	        correo=teclado.next();
	        p.setEmail(correo);
	        System.out.print("Introduzca password:");
	        pass=teclado.next();
	        p.setPass(pass);

	        espectadores.add(p);
	        
	        actualizar_fichero();
	        
	        
	       
	        
	        
   }
	 public static void eliminarEspectador() {
		 Scanner teclado = new Scanner(System.in);
		 int posicion;
		 for(int indice=0;indice<espectadores.size();indice++){	        	
	        	System.out.println(espectadores.get(indice));
	    
	        }
	        System.out.print("\nIntroduzca la posici�n del objeto que quieres eliminar comenzando desde la posicion 0: ");
	        posicion=teclado.nextInt();
	        espectadores.remove(posicion);
	        actualizar_fichero();

	 }
	 public static void mostrarEspectador() {
		 for(int indice=0;indice<espectadores.size();indice++){	        	
	        	System.out.println(espectadores.get(indice));
	    
	        }
	 }
	 public static void modificarEspectador() {
		 Scanner teclado = new Scanner(System.in);
		 int posicion;
		 int ID;
		 String nombre;
		 String apellido;
		 String nick;
		 String email;
		 String pass;
		 for(int indice=0;indice<espectadores.size();indice++){	        	
	        	System.out.println(espectadores.get(indice));
	    
	        }
		 	System.out.print("\nIntroduzca la posici�n del objeto que quieres modificar comenzando desde la posicion 0: ");
	        posicion=teclado.nextInt();
		 	System.out.print("\nIntroduzca el ID por el que desea modificarlo: ");
	        ID=teclado.nextInt();
	        espectadores.get(posicion).setUserId(ID);
	        System.out.print("\nIntroduzca el nombre por el que desea modificarlo: ");
	        nombre=teclado.next();
	        espectadores.get(posicion).setName(nombre);
	        System.out.print("\nIntroduzca el apellido por el que desea modificarlo: ");
	        apellido=teclado.next();
	        espectadores.get(posicion).setSurname(apellido);
	        System.out.print("\nIntroduzca el nick por el que desea modificarlo: ");
	        nick=teclado.next();
	        espectadores.get(posicion).setNick(nick);
	        System.out.print("\nIntroduzca el email de contacto por el que desea modificarlo: ");
	        email=teclado.next();
	        System.out.print("Introduzca la password por la que desea modificarla:");
	        pass=teclado.next();
	        
	        espectadores.get(posicion).setUserId(ID);
	        espectadores.get(posicion).setName(nombre);
	        espectadores.get(posicion).setSurname(apellido);
	        espectadores.get(posicion).setNick(nick);
	        espectadores.get(posicion).setEmail(email);
	        espectadores.get(posicion).setPass(pass);
	        actualizar_fichero();
}
	 public static void cargar_fichero(){
		 String ID_String;
		 String nombre;
		 String apellido;
		 String nick;
		 String correo;
		 String pass;
		 int ID;
		 
		//try {
			//FileWriter fichero = new FileWriter("espectadores.txt");
			//fichero.write("Holaaa");
			//fichero.close();
		//}catch(Exception ex) {ex.printStackTrace();}
		try {
			FileReader lector= new FileReader("espectadores.txt");
			BufferedReader BR = new BufferedReader(lector);
		
			while((ID_String = BR.readLine())!=null){
				nombre=BR.readLine();
				apellido=BR.readLine();
				nick=BR.readLine();
				correo=BR.readLine();
				pass=BR.readLine();
				ID=Integer.valueOf(ID_String);
				
				Espectador p = new Espectador();
				p.setUserId(ID);
				p.setName(nombre);
				p.setSurname(apellido);
				p.setNick(nick);
				p.setEmail(correo);
				p.setPass(pass);
				espectadores.add(p);
				mostrarEspectador();
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();}
			}


public static void actualizar_fichero() {
		try {
			FileWriter fichero = new FileWriter("espectadores.txt");
			for(int i=0;i<espectadores.size();i++) {
				fichero.write(espectadores.get(i).getUserId()+"\n");
				fichero.write(espectadores.get(i).getName()+"\n");
				fichero.write(espectadores.get(i).getSurname()+"\n");
				fichero.write(espectadores.get(i).getNick()+"\n");
				fichero.write(espectadores.get(i).getEmail()+"\n");
				fichero.write(espectadores.get(i).getPass()+"\n");
			}
			
			fichero.close();
		}catch(Exception ex) {ex.printStackTrace();}
}
	
public static boolean iniciar_sesion(String Nick, String pass) {
	boolean check = false;

	for(int i=0;i<espectadores.size();++i) {
		if((espectadores.get(i).getPass().equals(pass))&&(espectadores.get(i).getNick().equals(Nick))) {
			check=true;
		}else {
			check=false;
		}
	}
	return check;
}
	public static void crear_critica() throws IOException {
		 Scanner teclado = new Scanner(System.in);
	        Critica p;
	        p= new Critica();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

	 
	        String titulo;
	        int puntuacion;
	        String resenia;
	        String nick;
	        
	        System.out.print("Introduzca el titulo:  ");
	        titulo = reader.readLine();
	        p.setTitulo(titulo);
	        System.out.print("Introduzca la puntuacion otorgada:  ");
	        puntuacion = teclado.nextInt();
	        p.setPuntuaciones(puntuacion);
	        System.out.print("Introduzca la resenia: ");
	        resenia = reader.readLine();
	        p.setResena(resenia);
	        System.out.print("Introduzca el nick: ");
	        nick = reader.readLine();
	        p.setUsuario(nick);
	      

	        criticas.add(p);
	        
	}
	public static void mostrar_criticas() {
		for(int indice=0;indice<criticas.size();indice++){	        	
        	System.out.println(criticas.get(indice));
        }
	}
	public static void borrar_critica() {
		Scanner teclado = new Scanner(System.in);
		System.out.print("\nIntroduzca el titulo:  ");
		String titulo = teclado.next();
		System.out.print("\n�Que usuario eres ? ");
		String nick = teclado.next();
		for(int i = 0; i < criticas.size();++i) {
			if(criticas.get(i).getUsuario().equals(nick) && criticas.get(i).getTitulo().equals(titulo)) {
				criticas.remove(i);
			}
			
		}
	}
	public static void votar_critica() {
		Scanner teclado = new Scanner(System.in);
		System.out.print("\nIntroduzca el titulo:  ");
		String titulo = teclado.next();
		System.out.print("\n�Que usuario eres ? ");
		String nick = teclado.next();
		
		for(int i = 0; i < criticas.size();++i) {
			if(!criticas.get(i).getUsuario().equals(nick) && criticas.get(i).getTitulo().equals(titulo)) {
				System.out.print("\n Valoracion :  ");
				int valoracion = teclado.nextInt();
				criticas.get(i).setValoracion(valoracion);
			}
			
		}
		
	}
	public static void buscar_critica() {
		Scanner teclado = new Scanner(System.in);
		System.out.print("\n�Que usuario eres ? ");
		String nick = teclado.next();
		for(int i = 0; i < criticas.size();++i) 
		{
			if(criticas.get(i).getUsuario().equals(nick)) {
	        	System.out.println(criticas.get(i));
			}
		}
	}
	
	
}

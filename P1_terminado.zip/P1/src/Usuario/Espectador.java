package Usuario;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

public  class Espectador extends Usuario{
	private int userId; //Identificador del usuario debe ser �nico
	private String name; //Nombre del usuario
	private String surname; //Apellidos del usuario
	private String nick; //Nick del usuario
	private String email; //Email del usuario
	private String pass;//Contrase�a del usuario
	
	
	
	


	public Espectador() {
		// TODO Auto-generated constructor stub
	}
	


	public int getUserId() {
		return userId;
	}
	

	public String getName() {
		return name;
	}
	
	
	public String getSurname() {
		return surname;
	}
	

	public String getNick() {
		return nick;
	}
	
	
	public String getEmail() {
		return email;
	}
	

	public String getType() {
		return "Spectator";
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	public  void setName(String name) {
		this.name = name;	
	}
	
	
	public void setSurname(String surname) {
		this.surname = surname;	
	}
	
	
	public void setNick(String nick) {
		this.nick = nick;	
	}
	
	
	public void setEmail(String email) {
		this.email = email;	
	}
	public String getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}
	public String toString() {
        StringBuilder sb = new StringBuilder();  
        sb.append("\nId: ");
        sb.append(userId);
        sb.append("\nNAME: ");
        sb.append(name);
        sb.append("\nSURNAME: ");
        sb.append(surname);
        sb.append("\nNICK: ");
        sb.append(nick);
        sb.append("\nEMAIL: ");
        sb.append(email);    
        sb.append("\nPASSWORD: ");
        sb.append(pass);   
        return sb.toString();
    }

}

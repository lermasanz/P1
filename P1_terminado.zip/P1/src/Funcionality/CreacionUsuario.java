package Funcionality;

import Usuario.ADMIN;
import Usuario.Usuario;
import Usuario.Espectador;


public class CreacionUsuario {
	public static Usuario getUsuario(String type) {
		if("Espectador".equalsIgnoreCase(type)) {
			return new Espectador();
		}
		if("Admin".equalsIgnoreCase(type)) {
			return new ADMIN();
		}
		return null;
	}
	

}

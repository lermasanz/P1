package Espectaculos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import Gestores.Functions;

public class Multi_espectaculo extends Espectaculo {

	
	private int id_espectaculo;
	private String titulo;
	private String descripcion;
	private String categoria;
	private int aforo_maximo;
	private static DateTimeFormatter formatAmerican = DateTimeFormatter.ofPattern("yyyy/LL/dd");
    private LocalDate fecha = LocalDate.parse("1970/01/01", formatAmerican);
	
	
	
	private ArrayList<Sesion> sesiones= new ArrayList<Sesion>();
	
	public Multi_espectaculo()
	{
		
		
	}
	
	public int getId_espectaculo()
	{
		return id_espectaculo;
	}
	
	public String getTitulo()
	{
		return titulo;
	}
	
	public String getDescripcion()
	{
		return descripcion;
	}
	
	public String getCategoria()
	{
		return categoria;
		
	}
	
	public int getAforo()
	{
		return aforo_maximo;
	}
	
	
	
	public LocalDate getFecha() {
        return fecha;
    }
	
	public String getTipo()
	{
		return "Multiple";
	}
	
	public void setId_espectaculo(int id_espectaculo)
	{
		this.id_espectaculo=id_espectaculo;
	}
	
	public void setTitulo(String titulo)
	{
		this.titulo=titulo;
	}
	public void setDescripcion(String descripcion)
	{
		this.descripcion=descripcion;
		
	}
	public void setCategoria(String categoria)
	{
		this.categoria=categoria;
	}
	
	public void setAforo(int aforo_maximo)
	{
		this.aforo_maximo=aforo_maximo;
	}
	
	
	
	public void setFecha(String fecha) {

        this.fecha = Functions.parseFecha(fecha);
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}

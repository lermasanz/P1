package Espectaculos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Gestores.Functions;


public class Sesion {
	
	private int numero_entradas;
	private static DateTimeFormatter formatAmerican = DateTimeFormatter.ofPattern("yyyy/LL/dd");
    private LocalDate fecha = LocalDate.parse("1970/01/01", formatAmerican);
	
	public Sesion() {
		
	}
	
	public int getEntradas() {
		return numero_entradas;
	}
	
	public LocalDate getFecha() {
		return fecha;
	}
	
	public void setEntradas(int numero_entradas)
	{
		this.numero_entradas=numero_entradas;
	}
	
	public void setFecha(String fecha) {

        this.fecha = Functions.parseFecha(fecha);
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

}

module P1 {
}
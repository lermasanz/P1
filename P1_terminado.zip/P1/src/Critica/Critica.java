package Critica;

import java.util.ArrayList;

public class Critica {
    private String titulo;
    
    private String resena;
    
    private int puntuaciones;
    
    public int getPuntuaciones() {
		return puntuaciones;
	}

	public void setPuntuaciones(int puntuaciones) {
		this.puntuaciones = puntuaciones;
	}

	private int valoracion;
    
    private String usuario;




	public int getValoracion() {
		return valoracion;
	}

	public void setValoracion(int valoracion2) {
		this.valoracion = valoracion2;
	}

	public Critica() {

    }

    public String getTitulo() {
        return titulo;
    }

    public String getResena() {
        return resena;
    }

    
    

    public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setResena(String resena) {
       this.resena = resena;
    }
	public String toString() {
        StringBuilder sb = new StringBuilder();  
        sb.append("\nTitulo: ");
        sb.append(titulo);
        sb.append("\nResena: ");
        sb.append(resena);
        sb.append("\nPuntuaciones: ");
        sb.append(puntuaciones);
        sb.append("\nUsuario/Nick: ");
        sb.append("usuario");
        

        return sb.toString();
    }

   
}
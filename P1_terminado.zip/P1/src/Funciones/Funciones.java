package Funciones;

import java.util.Iterator;

import java.util.Scanner;
import java.util.ArrayList;

import Usuario.Usuario;
import Usuario.Espectador;
import Usuario.ADMIN;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

import java.io.IOException;


public class Funciones {
	
}

 
package Funciones;

import java.util.Scanner;

import Usuario.Espectador;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Iterator;
import Gestores.GestorUsuario;
import Gestores.GestorEspectaculos;
public class Menu {
	 public static void main(String[] args) throws NumberFormatException, IOException {
		 
		 	String Nick;
		 	String pass;
	        Scanner sin = new Scanner(System.in);
	        boolean salir = false;
	        int opcion;
	        int select;
	        Espectador p;
    		GestorUsuario.cargar_fichero();//Lectura del fichero donde se encuentran los usuarios.

	        p= new Espectador();
	        System.out.println("_________________________");
        	System.out.println("_________________________");
        	System.out.println("                         ");
        	System.out.println("	 BIENVENIDO      	");
         	System.out.println("                         ");
        	System.out.println("	 Iniciar_Sesion--> 0	");
        	System.out.println("	 Registrarse--> 1	");
        	System.out.println("                         ");
        	System.out.println("_________________________");
        	System.out.println("_________________________");
        	
        	int selection = sin.nextInt();
        		if(selection==0) {
        				System.out.print("Usuario/Nick: ");
    	                Nick = sin.next();

        				System.out.print("Contrase�a/Password: ");
    	                pass = sin.next();
    	                
    	                if(GestorUsuario.iniciar_sesion(Nick,pass)==true) {
    	                	System.out.print("Inicio de sesion correcto.\n");
    	                }else {
    	                	System.out.print("Asegurese de que se encuentre registrado...\n ");
    	        			GestorUsuario.leerEspectador();

    	                }


        		}else if(selection==1) {
        			GestorUsuario.leerEspectador();
        		}
	        while (!salir) {
	        	System.out.println("_________________________");
	        	System.out.println("_________________________");
	        	System.out.println("                         ");
	        	System.out.println("	 BIENVENIDO		 ");
	        	System.out.println("                         ");
	        	System.out.println("_________________________");
	        	System.out.println("_________________________");
	 
	            System.out.println("1. Usuario");
	            System.out.println("2. Administrador");
	            System.out.println("3. Critica");
	            System.out.println("4. Salir");
	 
	            try {
	 
	                System.out.println("Escribe una de las opciones");
	                opcion = sin.nextInt();
	 
	                switch (opcion) {
	                    case 1:
	                        System.out.println("---------------Modo Gestion Usuario-------------");
	                        System.out.println("1. Dar alta usuario");
	        	            System.out.println("2. Dar baja usuario");
	        	            System.out.println("3. Consultar datos de usuario ");
	        	            System.out.println("4. Actualizar datos de usuario");
	        	            System.out.println("5. Salir");

	        	            
	        	            select=sin.nextInt();
	        	            switch(select) {
	        	            	case 1:
	        	            		System.out.println("-----Alta Usuario-----");
	        	            		//0GestorUsuario.cargar_fichero();//Lectura del fichero donde se encuentran los usuarios.
	        	            		GestorUsuario.leerEspectador();
	 
	        	            		break;

	        	            	case 2:
	        	            		System.out.println("-----Baja Usuario-----");
	        	            		GestorUsuario.eliminarEspectador();
	        	            		break;
	        	            	case 3:
	        	            		System.out.println("-----Consulta Usuario-----");
	        	            		GestorUsuario.mostrarEspectador();
	  	        	            		break;
	        	            	case 4:
	        	            		System.out.println("-----Modificar/Actualizar-----");
	        	            		GestorUsuario.modificarEspectador();
	        	            		GestorUsuario.mostrarEspectador();
	        	            		break;
	        	            	case 5:
	        	            		System.out.println("-----ADIOS!!-----");
	        	            		break;
	        	            }
	        	            

	                     
	                    case 2:
	                    	  System.out.println("---------------Modo Gestion Criticas-------------");
		                        System.out.println("1. Crear critica");
		        	            System.out.println("2. Consultar Critica");
		        	            System.out.println("3. Borrar Critica ");
		        	            System.out.println("4. Votar Critica"); 
		        	            System.out.println("5. Buscar Critica");
		        	            System.out.println("6. Salir");
	                        
		        	            select=sin.nextInt();
		        	            switch(select) {
		        	            	case 1:
		        	            		System.out.println("-----Crear Critica-----");
		        	            		GestorUsuario.crear_critica();//Lectura del fichero donde se encuentran los usuarios.
		        	            		//GestorUsuario.leerEspectador();
		 
		        	            		break;

		        	            	case 2:
		        	            		System.out.println("-----Consultar Critica-----");
		        	            		GestorUsuario.mostrar_criticas();
		        	            		break;
		        	            	case 3:
		        	            		System.out.println("-----Borrar Critica-----");
		        	            		GestorUsuario.borrar_critica();
		  	        	            		break;
		        	            	case 4:
		        	            		System.out.println("-----Votar Critica-----");
		        	            		GestorUsuario.votar_critica();
		        	            		
		        	            		break;
		        	            	case 5: 
		        	            		System.out.println("-----Buscar Critica-----");
		        	            		GestorUsuario.buscar_critica();
		        	            		
		        	            	case 6:
		        	            		System.out.println("-----ADIOS!!-----");
		        	            		break;
		        	            }
	                    case 3:
	                    	System.out.println("------------Modo Gestion Espectaculos---------------");
	        				System.out.println("1. A�adir espectaculo.");
	        				System.out.println("2. Cancelar espectaculo.");
	        				System.out.println("3. Actualizar espectaculo.");
	        				System.out.println("4. Buscar espectaculo.");
	        				System.out.println("5. Ver proximos espectaculos con entradas disponibles.");
	        				System.out.println("6. Ver entradas disponibles para una sesion de un espectaculo.");
	        				System.out.println("7. Ver entradas vendidas para una sesion de un espectaculo.");
	        				System.out.println("5. Salir.");
	        				select = sin.nextInt();
	        					
	        				switch(select)
	        				{
	        					case 1:
	        						
	        					System.out.println("A�adir espectaculo");
	        					GestorEspectaculos.AltaEspectaculo();
	        					System.out.println("Se ha a�adido correctamente");
	        					GestorEspectaculos.mostrarEspectaculo();
	        					break;
	        				
	        					case 2:
	        						
	        						System.out.println("Cancelar Espectaculo");
	        						GestorEspectaculos.mostrarEspectaculo();
	        						GestorEspectaculos.CancelarEspectaculo();
	        						GestorEspectaculos.mostrarEspectaculo();
	        						System.out.println("Se ha eliminado correctamente");
	        						break;
	        		
	        					case 3:
	        						
	        						System.out.println("Actualizar Espectaculo");
	        						GestorEspectaculos.ActualizarEspectaculo();
	        						System.out.println("Se ha actualizado correctamente");
	        						break;
	        						
	        						
	        					case 4:
	        						
	        						System.out.println("Buscar Espectaculo");
	        						GestorEspectaculos.BuscarEspectaculo();
	        						System.out.println("Se ha realizado correctamente");
	        						
	        						
	        						
	        						break;
	        						
	        						
	        					case 5: 
	        						
	        						System.out.println("Espectaculos Disponibles");
		        					GestorEspectaculos.EspectaculosDisponibles();
		        					System.out.println("Se ha realizado correctamente");
		        					break;
		        					
		        					
	        					case 6:
	        						
	        						System.out.println("Entradas Disponibles");
		        					
		        					GestorEspectaculos.EntradasDisponibles();
		        					System.out.println("Se ha realizado correctamente");
		        					break;
		        					
	        					case 7:
	        						
	        						System.out.println("Entradas Vendidas");
		        					
		        					GestorEspectaculos.EntradasVendidas();
		        					System.out.println("Se ha realizado correctamente");
		        					
		        					break;
		        					
	        				}
	                    case 4:
	                        salir = true;
	                        break;
	                    default:
	                        System.out.println("Solo n�meros entre 1 y 4");
	                }
	            } catch (InputMismatchException e) {
	                System.out.println("Debes insertar un n�mero");
	                sin.next();
	            }
	        }
	 
	    }
}
